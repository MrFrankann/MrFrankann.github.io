// Filtro Js


$(document).ready(function(){
    $('.filter-item').click(function(){
        const value = $(this).attr('data-filter');
        if (value == 'todos'){
            $('.post-box').show('1000');
        }
        else{
            $('.post-box').not('.' + value).hide('1000');
            $('.post-box').filter('.' + value).show('1000');
        }
    });
    //Adicionar cor ao botao selecionado
    $(".filter-item").click(function(){
        $(this).addClass("active-filter").siblings().removeClass("active-filter");
    })
});


// Testemunhos
const testimonials = [
    {
      image: "imgs/testemunho1.jpg",
      name: "Maria Santos",
      text: "Participar da Aequalitas mudou minha vida. ",
    },
    {
      image: "imgs/testemunho2.jpg",
      name: "Luís Pereira",
      text: "Nunca pensei que eu poderia contribuir tanto para a sociedade até me envolver com a Aequalitas.",
    },
    {
      image: "imgs/testemunho3.jpg",
      name: "Ana Silva",
      text: "A Aequalitas é mais do que uma ONG, é uma família. Trabalhamos juntos para promover a igualdade.",
    },
    {
      image: "imgs/testemunho4.jpg",
      name: "Carlos Rodrigues",
      text: "Os projetos da Aequalitas têm um impacto real nas vidas das pessoas.",
    },
    {
      image: "imgs/testemunho5.jpg",
      name: "Mariana Almeida",
      text: "Juntei-me à Aequalitas como voluntária e encontrei um propósito maior.",
    },
    {
      image: "imgs/testemunho6.jpg",
      name: "Ricardo Santos",
      text: "A Aequalitas me deu uma plataforma para defender o que acredito.",
    },
    {
      image: "imgs/testemunho7.jpg",
      name: "Sofia Oliveira",
      text: "A Aequalitas é como uma chama de esperança. Estamos comprometidos em criar um mundo onde todos tenham oportunidades iguais."
    },
    // Adicione mais testemunhos fictícios aqui
  ];
 
let currentTestimonial = 0;
const testimonialsPerSlide = 3;
const totalTestimonials = testimonials.length;

function showTestimonials() {
  const testimonialContainer = document.getElementById("testimonial-container");
  testimonialContainer.innerHTML = "";

  for (let i = 0; i < testimonialsPerSlide; i++) {
    const testimonial = testimonials[(currentTestimonial + i) % totalTestimonials];

    const testimonialCard = `
      <div class="card" style="width: 16rem;">
        <img src="${testimonial.image}" class="card-img-top" alt="Imagem do Testemunho">
        <div class="card-body">
          <p class="card-text ">${testimonial.text}</p>
        </div>
        <div class="card-footer">
          <small class="text-muted">${testimonial.name}</small>
        </div>
      </div>
    `;

    testimonialContainer.innerHTML += testimonialCard;
  }
}

function nextTestimonials() {
    currentTestimonial = (currentTestimonial + 1) % totalTestimonials;
    showTestimonials();
  }

  function prevTestimonials() {
    currentTestimonial = (currentTestimonial - 1 + totalTestimonials) % totalTestimonials;
    showTestimonials();
  }  

showTestimonials();
nextTestimonials(); // Chama a função para exibir os testemunhos imediatamente

setInterval(nextTestimonials, 5000); // Mude a cada 5 segundos
