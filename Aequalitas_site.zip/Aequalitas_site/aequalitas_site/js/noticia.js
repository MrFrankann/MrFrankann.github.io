let blogId = decodeURI(location.pathname.split("/").pop());

let docRef = db.collection("blogs").doc(blogId);

docRef.get().then((doc) => {
    if(doc.exists){
        setupBlog(doc.data());
    } else{
        location.replace("/");
    }
})

const setupBlog = (data) => {
    const banner = document.querySelector('.banner');
    const blogTitle = document.querySelector('.title');
    const titleTag = document.querySelector('title');
    const publish = document.querySelector('.published');
    
    banner.style.backgroundImage = `url(${data.bannerImage})`;

    titleTag.innerHTML += blogTitle.innerHTML = data.title;
    publish.innerHTML += data.publishedAt;

    const article = document.querySelector('.article');
    addArticle(article, data.article);
    translateTextEN();
    translateTextES();
    translateTextIT();
    translateTextFR();
}

const addArticle = (ele, data) => {
    data = data.split("\n").filter(item => item.length);
    // console.log(data);

    let imageRow = ''; // Variável para manter as imagens em uma linha

    data.forEach(item => {
        // check for heading
        if (item[0] == '#') {
            let hCount = 0;
            let i = 0;
            while (item[i] == '#') {
                hCount++;
                i++;
            }
            let tag = `h${hCount}`;
            ele.innerHTML += `<${tag} class="textToTranslate">${item.slice(hCount, item.length)}</${tag}>`;
        }
        // checking for image format
        else if (item[0] == "!" && item[1] == "[") {
            let separator;

            for (let i = 0; i <= item.length; i++) {
                if (item[i] == "]" && item[i + 1] == "(" && item[item.length - 1] == ")") {
                    separator = i;
                }
            }

            let alt = item.slice(2, separator);
            let src = item.slice(separator + 2, item.length - 1);

            imageRow += `
                <img src="${src}" alt="${alt}" class="article-image" style="border-radius:5%; width:270px; height:270px; margin:10px;">
            `;
        } else {
            if (imageRow) {
                // Se houver imagens na linha, adicione-as dentro de uma div e redefina a linha
                ele.innerHTML += `<div style="display:flex; flex-wrap: wrap; justify-content: center;">${imageRow}</div>`;
                imageRow = ''; // Limpe a variável de linha de imagens
            }
            ele.innerHTML += `<p class="textToTranslate">${item}</p>`;
        }
    });

    if (imageRow) {
        // Certifique-se de adicionar as imagens restantes fora do loop
        ele.innerHTML += `<div style="display:flex; flex-wrap: wrap; justify-content: center;">${imageRow}</div>`;
    }
};


