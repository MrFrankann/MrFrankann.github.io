const blogSection = document.querySelector('.blogs-section');

// Coletar os projetos e armazená-los em um array
const blogsArray = [];

db.collection("blogs").get().then((blogs) => {
    blogs.forEach(blog => {
        if (blog.id != decodeURI(location.pathname.split("/").pop())) {
            blogsArray.push(blog);
        }
    });

    // Ordenar o array com base na data de início (DD/MM/YYYY)
    blogsArray.sort((a, b) => {
        const dataA = parseDate(a.data().data_inicio);
        const dataB = parseDate(b.data().data_inicio);
        return dataB - dataA; // Ordene do mais recente para o mais antigo
    });

    // Renderizar os projetos na ordem classificada
    blogsArray.forEach(blog => {
        createBlog(blog);
        translateTextEN();
        translateTextES();
        translateTextIT();
        translateTextFR();
    });
});

const createBlog = (blog) => {
    let data = blog.data();
    blogSection.innerHTML += `
    <article class="postcard light blue post-box ${data.projeto}">
                <a class="postcard__img_link" href="/${blog.id}">
                  <img class="postcard__img" src="${data.bannerImage}" alt="Image Title" />
                </a>
                <div class="postcard__text t-dark">
                  <h1 class="postcard__title blue"><a class="textToTranslate" href="/${blog.id}">${data.title.substring(0, 100) + '...'}</a></h1>
                  <div class="postcard__subtitle small">
                    <time datetime="${data.data_inicio}" class="calendar">
                      <i class="fas fa-calendar-alt mr-2"></i class="textToTranslate"> <a class="textToTranslate"> De ${data.data_inicio} a ${data.data_fim}</a>
                    </time>
                  </div>
                  <div class="postcard__bar"></div>
                  <div class="postcard__preview-txt textToTranslate">${data.article.substring(0, 120) + '...'}</div>
                  <ul class="postcard__tagbox">
                    <li class="tag__item"><i class="fas fa-tag mr-2"></i> <a class="textToTranslate">${data.tipo_de_projeto}</a></li>
        
                    <li class="tag__item play blue">
                      <a href="/${blog.id}"><i class="fas fa-play mr-2"></i><a class="textToTranslate" href="/${blog.id}">Ver Projeto</a></a>
                    </li>
                  </ul>
                </div>
              </article>
    `;
}

// Função para analisar a data no formato DD/MM/YYYY
function parseDate(dateString) {
  const [day, month, year] = dateString.split('/').map(Number);
  return new Date(year, month - 1, day);
}


$(document).ready(function(){
    $('.filter-item').click(function(){
        const value = $(this).attr('data-filter');
        if (value == 'todos'){
            $('.post-box').show('1000');
        }
        else{
            $('.post-box').not('.' + value).hide('1000');
            $('.post-box').filter('.' + value).show('1000');
        }
    });
    //Adicionar cor ao botao selecionado
    $(".filter-item").click(function(){
        $(this).addClass("active-filter").siblings().removeClass("active-filter");
    })
});

