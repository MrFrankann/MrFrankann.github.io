const blogTitleField = document.querySelector('.title');
const articleFeild = document.querySelector('.article');
const dataInicioField = document.querySelector('.data_inicio');
const dataFimField = document.querySelector('.data_fim');

let projetoField = '';
let tipoDeProjetoField = '';

// Selecione o elemento <select> pelo seletor de classe
const selectElement = document.querySelector('.form-control.mb-2.select2');

// Função para ler os valores quando a seleção for alterada
function lerValoresSelecionados() {
  projetoField = selectElement.options[selectElement.selectedIndex].getAttribute('data-projeto');
  tipoDeProjetoField = selectElement.options[selectElement.selectedIndex].getAttribute('data-tipo-de-projeto');
}

// Adicione um ouvinte de evento para o evento 'change' no elemento <select>
selectElement.addEventListener('change', lerValoresSelecionados);


// banner
const bannerImage = document.querySelector('#banner-upload');
const banner = document.querySelector(".bannernoticia");
let bannerPath;

const publishBtn = document.querySelector('.publish-btn');
const uploadInput = document.querySelector('#image-upload');

bannerImage.addEventListener('change', () => {
    uploadImage(bannerImage, "banner");
})

uploadInput.addEventListener('change', () => {
    uploadImage(uploadInput, "image");
})

const uploadImage = (uploadFile, uploadType) => {
    const [file] = uploadFile.files;
    if(file && file.type.includes("image")){
        const formdata = new FormData();
        formdata.append('image', file);

        fetch('/upload', {
            method: 'post',
            body: formdata
        }).then(res => res.json())
        .then(data => {
            if(uploadType == "image"){
                addImage(data, file.name);
            } else{
                bannerPath = `${location.origin}/${data}`;
                banner.style.backgroundImage = `url("${bannerPath}")`;
            }
        })
    } else{
        alert("upload Image only");
    }
}

const addImage = (imagepath, alt) => {
    let curPos = articleFeild.selectionStart;
    let textToInsert = `\r![${alt}](${imagepath})\r`;
    articleFeild.value = articleFeild.value.slice(0, curPos) + textToInsert + articleFeild.value.slice(curPos);
}

let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

publishBtn.addEventListener('click', () => {
    if( articleFeild.value.length &&
        blogTitleField.value.length &&
        dataInicioField.value.length &&
        dataFimField.value.length &&
        projetoField.length &&
        tipoDeProjetoField.length){
        // generating id
        let letters = 'abcdefghijklmnopqrstuvwxyz';
        let blogTitle = blogTitleField.value.split(" ").join("-");
        let id = '';
        for(let i = 0; i < 4; i++){
            id += letters[Math.floor(Math.random() * letters.length)];
        }

        // setting up docName
        let docName = `${blogTitle}-${id}`;
        let date = new Date(); // for published at info


        //access firstore with db variable;
        db.collection("blogs").doc(docName).set({
            title: blogTitleField.value,
            article: articleFeild.value,
            bannerImage: bannerPath,
            publishedAt: `De ${dataInicioField.value} a ${dataFimField.value}`,
            data_inicio: dataInicioField.value,
            data_fim: dataFimField.value,
            projeto: projetoField,
            tipo_de_projeto: tipoDeProjetoField
        })
        .then(() => {
            location.href = `/${docName}`;
        })
        .catch((err) => {
            console.error(err);
        })
    }
})
