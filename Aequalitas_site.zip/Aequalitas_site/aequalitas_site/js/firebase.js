let firebaseConfig = {
    apiKey: "AIzaSyCTcl38MNfSKlVUXShKVdAoAvIWokTwZ5w",
    authDomain: "blogging-website-464e11.firebaseapp.com",
    projectId: "blogging-website-464e11",
    storageBucket: "blogging-website-464e11.appspot.com",
    messagingSenderId: "799209754172",
    appId: "1:799209754172:web:c0447ca15e9ba1048cfd39"
  };

firebase.initializeApp(firebaseConfig);

let db = firebase.firestore();