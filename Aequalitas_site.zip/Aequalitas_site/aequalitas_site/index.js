// Testemunhos
const testimonials = [
    {
      image: "imgs/testemunho1.jpeg",
      name: "Luísa, Intercâmbio de Jovens",
      text: "A comida, as paisagens, as experiências de vida diversas das pessoas e os costumes georgianos colocaram-me numa posição fora da zona de conforto, que, sem preconceitos, me fizeram abrir a novas culturas. ",
    },
    {
      image: "imgs/testemunho2.jpeg",
      name: "Guilherme, Voluntariado CES",
      text: "A experiência de viver no estrangeiro, ajudar numa pequena comunidade e ver de perto e sentir os costumes de outro país fazem desta uma experiência enriquecedora, que acho que quem tiver essa hipótese não devia deixar passar.",
    },
    {
      image: "imgs/testemunho3.jpeg",
      name: "Lucas, Projeto de Solidariedade",
      text: "Ao longo das sessões e dos momentos de diálogos foi criado e fortalecido um espaço seguro onde fui capaz de expressar a minha identidade de género e partilhar a minha experiência como uma pessoa quer.",
    },
    {
      image: "imgs/testemunho4.jpeg",
      name: "Tomás, Intercâmbio de Jovens",
      text: "Achei o projeto muito interessante e fez-me evoluir muito como pessoa, conheci pessoas e culturas novas, os seus costumes e maneira de viver etc. Também pratiquei vários hábitos e rotinas ecológicas que espero levar comigo para o resto da minha vida.",
    },
    {
      image: "imgs/testemunho5.jpeg",
      name: "Maria Carolina, Voluntariado CES",
      text: "Depois desta experiência, não há ninguém a quem não recomende o European Solidarity Corps (e a orientação da Aequalitas). Penso verdadeiramente que tornam o sonho de tantos nós de “fazer voluntariado internacional” em algo concreto e ao nosso alcance. Na dúvida, vai!",
    },
    // Adicione mais testemunhos fictícios aqui
  ];
 
let currentTestimonial = 0;
const testimonialsPerSlide = 3;
const totalTestimonials = testimonials.length;

function showTestimonials() {
  const testimonialContainer = document.getElementById("testimonial-container");
  testimonialContainer.innerHTML = "";

  for (let i = 0; i < testimonialsPerSlide; i++) {
    const testimonial = testimonials[(currentTestimonial + i) % totalTestimonials];

    const testimonialCard = `
      <div class="card" style="width: 16rem;">
        <img src="${testimonial.image}" class="card-img-top" alt="Imagem do Testemunho">
        <div class="card-body">
          <p class="card-text textToTranslate">${testimonial.text}</p>
        </div>
        <div class="card-footer">
          <small class="text-muted textToTranslate">${testimonial.name}</small>
        </div>
      </div>
    `;

    testimonialContainer.innerHTML += testimonialCard;
  }
}

function nextTestimonials() {
    currentTestimonial = (currentTestimonial + 1) % totalTestimonials;
    showTestimonials();
    translateTextEN();
    translateTextES();
    translateTextIT();
    translateTextFR();
  }

  function prevTestimonials() {
    currentTestimonial = (currentTestimonial - 1 + totalTestimonials) % totalTestimonials;
    showTestimonials();
    translateTextEN();
    translateTextES();
    translateTextIT();
    translateTextFR();
  }  

showTestimonials();
nextTestimonials(); // Chama a função para exibir os testemunhos imediatamente

setInterval(nextTestimonials, 5000); // Mude a cada 5 segundos
