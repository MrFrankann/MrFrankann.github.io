//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol//Espanhol

// Função para recarregar a página e, em seguida, traduzir
function reloadAndTranslateES() {
    // Adicione ou atualize o parâmetro "translate" na URL
    window.location.href = window.location.href.replace(/\?language=.*/, "");
    const url = new URL(window.location.href);
    url.searchParams.set("language", "es");
    window.location.href = url.toString();
}

// Verifique se o parâmetro "translate" está na URL
function shouldTranslateES() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get("language") === "es";
}

// Função para traduzir o texto para italiano
function translateTextES() {
if (shouldTranslateES()) {
    var elementsToTranslate = document.querySelectorAll(".textToTranslate");
    var targetLang = 'es'; // Idioma de destino
    var apiKey = 'AIzaSyB8Qvpvm8D9dzxr45FSv5Ojmb1Pf0d9cTE'; // Substitua pela sua chave de API

    var apiUrl = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;

    elementsToTranslate.forEach(function (element) {
        var textToTranslate = element.textContent;
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                q: textToTranslate,
                source: 'pt', // Idioma de origem
                target: targetLang,
            }),
        })
        .then(response => response.json())
        .then(data => {
            var translatedText = data.data.translations[0].translatedText;

            // Decodificar entidades HTML no texto traduzido
            var tempElement = document.createElement("div");
            tempElement.innerHTML = translatedText;
            translatedText = tempElement.textContent;

            element.textContent = translatedText; // Substitui o texto original pelo traduzido
            changeImage('imgs/Spain.png'); 
        })
        .catch(error => {
            console.error('Erro ao traduzir:', error);
        });
    });
}
}

// Traduza o texto se o parâmetro "translate" estiver na URL
translateTextES();



//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues//Portugues

    function reloadAndTranslatePT() {
        window.location.href = window.location.href.replace(/\?language=.*/, "");
        changeImage('imgs/portugal.png'); 
    }


//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles//Ingles

// Função para recarregar a página e, em seguida, traduzir
function reloadAndTranslateEN() {
    // Adicione ou atualize o parâmetro "translate" na URL
    window.location.href = window.location.href.replace(/\?language=.*/, "");
    const url = new URL(window.location.href);
    url.searchParams.set("language", "en");
    window.location.href = url.toString();
}

// Verifique se o parâmetro "translate" está na URL
function shouldTranslateEN() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get("language") === "en";
}

// Função para traduzir o texto para iNGLES
function translateTextEN() {
if (shouldTranslateEN()) {
    var elementsToTranslate = document.querySelectorAll(".textToTranslate");
    var targetLang = 'en'; // Idioma de destino
    var apiKey = 'AIzaSyB8Qvpvm8D9dzxr45FSv5Ojmb1Pf0d9cTE'; // Substitua pela sua chave de API

    var apiUrl = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;

    elementsToTranslate.forEach(function (element) {
        var textToTranslate = element.textContent;
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                q: textToTranslate,
                source: 'pt', // Idioma de origem
                target: targetLang,
            }),
        })
        .then(response => response.json())
        .then(data => {
            var translatedText = data.data.translations[0].translatedText;

            // Decodificar entidades HTML no texto traduzido
            var tempElement = document.createElement("div");
            tempElement.innerHTML = translatedText;
            translatedText = tempElement.textContent;

            element.textContent = translatedText; // Substitui o texto original pelo traduzido
            changeImage('imgs/ingles.png'); 
        })
        .catch(error => {
            console.error('Erro ao traduzir:', error);
        });
    });
}
}

// Traduza o texto se o parâmetro "translate" estiver na URL
translateTextEN();



//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano//Italiano

// Função para recarregar a página e, em seguida, traduzir
function reloadAndTranslateIT() {
    // Adicione ou atualize o parâmetro "translate" na URL
    window.location.href = window.location.href.replace(/\?language=.*/, "");
    const url = new URL(window.location.href);
    url.searchParams.set("language", "it");
    window.location.href = url.toString();
}

// Verifique se o parâmetro "translate" está na URL
function shouldTranslateIT() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get("language") === "it";
}

// Função para traduzir o texto para italiano
function translateTextIT() {
if (shouldTranslateIT()) {
    var elementsToTranslate = document.querySelectorAll(".textToTranslate");
    var targetLang = 'it'; // Idioma de destino
    var apiKey = 'AIzaSyB8Qvpvm8D9dzxr45FSv5Ojmb1Pf0d9cTE'; // Substitua pela sua chave de API

    var apiUrl = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;

    elementsToTranslate.forEach(function (element) {
        var textToTranslate = element.textContent;
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                q: textToTranslate,
                source: 'pt', // Idioma de origem
                target: targetLang,
            }),
        })
        .then(response => response.json())
        .then(data => {
            var translatedText = data.data.translations[0].translatedText;

            // Decodificar entidades HTML no texto traduzido
            var tempElement = document.createElement("div");
            tempElement.innerHTML = translatedText;
            translatedText = tempElement.textContent;

            element.textContent = translatedText; // Substitui o texto original pelo traduzido
            changeImage('imgs/Italie.png'); 
        })
        .catch(error => {
            console.error('Erro ao traduzir:', error);
        });
    });
}
}

// Traduza o texto se o parâmetro "translate" estiver na URL
translateTextIT();




//Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances //Frances 


// Função para recarregar a página e, em seguida, traduzir
function reloadAndTranslateFR() {
    // Adicione ou atualize o parâmetro "translate" na URL
    window.location.href = window.location.href.replace(/\?language=.*/, "");
    const url = new URL(window.location.href);
    url.searchParams.set("language", "fr");
    window.location.href = url.toString();
}

// Verifique se o parâmetro "translate" está na URL
function shouldTranslateFR() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get("language") === "fr";
}

// Função para traduzir o texto para italiano
function translateTextFR() {
if (shouldTranslateFR()) {
    var elementsToTranslate = document.querySelectorAll(".textToTranslate");
    var targetLang = 'fr'; // Idioma de destino
    var apiKey = 'AIzaSyB8Qvpvm8D9dzxr45FSv5Ojmb1Pf0d9cTE'; // Substitua pela sua chave de API

    var apiUrl = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;

    elementsToTranslate.forEach(function (element) {
        var textToTranslate = element.textContent;
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                q: textToTranslate,
                source: 'pt', // Idioma de origem
                target: targetLang,
            }),
        })
        .then(response => response.json())
        .then(data => {
            var translatedText = data.data.translations[0].translatedText;

            // Decodificar entidades HTML no texto traduzido
            var tempElement = document.createElement("div");
            tempElement.innerHTML = translatedText;
            translatedText = tempElement.textContent;

            element.textContent = translatedText; // Substitui o texto original pelo traduzido
            changeImage('imgs/France.png'); 
        })
        .catch(error => {
            console.error('Erro ao traduzir:', error);
        });
    });
}
}

// Traduza o texto se o parâmetro "translate" estiver na URL
translateTextFR();

function changeImage(imageSrc) {
    var mainImage = document.getElementById('mainImage');
    mainImage.src = imageSrc;
}